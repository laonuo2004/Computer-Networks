Reliable File Transfer using Go-Back-N Protocol
Windows Executable Package

Student ID: 1120231863
Executable: 1120231863ReliableFileTransfer.exe

1. What this program does

This executable runs a reliable file transfer program over UDP. The program
implements the Go-Back-N protocol by itself instead of using TCP reliability.

The default demo starts two local hosts:

- Host1 sends data\host1.bin to Host2.
- Host2 sends data\host2.bin to Host1.
- Both transfers run at the same time.
- Received files are written to received\.
- Communication logs are written to logs\.
- Analysis results can be written to results\.

The executable must be kept in this folder together with configs\, data\,
logs\, received\, results\, and _internal\. Do not move only the exe file to
another folder.

2. Folder contents

1120231863ReliableFileTransfer\
|-- 1120231863ReliableFileTransfer.exe   main executable program
|-- _internal\                           PyInstaller runtime files
|-- configs\                             host configuration files
|-- data\                                input test files
|-- received\                            received output files
|-- logs\                                communication log files
|-- results\                             analysis result files
`-- README.txt                           this file

3. Recommended quick test

Open PowerShell in this folder, then run:

.\1120231863ReliableFileTransfer.exe demo --clean

The option --clean removes old logs\, received\, and results\ before running
the demo.

Expected output:

data/host1.bin -> received/from_host1.bin: OK
data/host2.bin -> received/from_host2.bin: OK

If both lines show OK, the two received files are identical to the original
input files according to SHA-256 comparison inside the program.

4. Analyze communication logs

After running the demo, run:

.\1120231863ReliableFileTransfer.exe analyze --log-dir logs --output-dir results

Expected output example:

analyzed 4 log files

The following files will be generated or updated:

results\summary.csv
results\summary.md
results\throughput.svg
results\retransmit.svg

5. Run one host manually

The executable can also start one host from a JSON configuration file.
For a two-host manual test, open two PowerShell windows in this folder.

PowerShell window 1:

.\1120231863ReliableFileTransfer.exe host configs\host1.json

PowerShell window 2:

.\1120231863ReliableFileTransfer.exe host configs\host2.json

The default ports are:

Host1: 127.0.0.1:41863
Host2: 127.0.0.1:41864
Host3: 127.0.0.1:41865
Host4: 127.0.0.1:41866

6. Generate test data again

The package already contains data\host1.bin and data\host2.bin. If the test
data files need to be regenerated, run:

.\1120231863ReliableFileTransfer.exe gen data\host1.bin
.\1120231863ReliableFileTransfer.exe gen data\host2.bin --seed 202

The default generated file size is larger than 3 MB.

7. Configuration files

The host behavior is controlled by JSON files in configs\. Important fields:

host_id       host name
local_ip      local UDP IP address
local_port    local UDP port
data_size     maximum DATA field size in one PDU
seq_bits      sequence number bits
sw_size       sender window size
init_seq_no   initial sequence number
timeout_ms    timeout value in milliseconds
error_rate    simulated PDU corruption rate, in percent
lost_rate     simulated PDU loss rate, in percent
peers         peer hosts and send/receive file paths

For the default demo, no configuration change is needed.

8. Notes

- This is a console program. Please run it from PowerShell.
- Windows may show a security warning for an executable built by PyInstaller.
  Choose to run it if the file comes from the submitted project package.
- The program uses relative paths, so commands should be run inside this
  folder.
- If the program reports that a port is already in use, close the old terminal
  process or wait for the port to be released, then run the command again.
