|log|send_count|retransmit_count|timeout_count|data_error_count|order_error_count|duration_s|throughput_kib_s|
|---|---|---|---|---|---|---|---|
|Host1_recv_Host2_ec50f047.csv|0|0|0|0|0|18.889924|162.63|
|Host1_to_Host2_f4dd0758.csv|3082|8|1|0|0|17.934774|0.00|
|Host2_recv_Host1_f4dd0758.csv|0|0|0|0|0|17.585591|174.70|
|Host2_to_Host1_ec50f047.csv|3074|0|0|0|0|18.903354|0.00|
